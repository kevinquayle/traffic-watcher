package com.example.traffic2;

import androidx.fragment.app.FragmentActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class Camera {
    private String name;
    private LatLng location;
    private String streamLink;
    private Direction direction;
    private double kilometerVelocity;
    private double mileVelocity;

    public Camera(String name, LatLng location, String streamLink, Direction direction) {
        this.name = name;
        this.location = location;
        this.streamLink = streamLink;
        this.direction = direction;
    }

    public String getName() {
        return name;
    }

    public LatLng getLocation() {
        return location;
    }

    public String getStreamLink() {
        return streamLink;
    }

    public void setKilometerVelocity(double kilometerVelocity) {
        this.kilometerVelocity = kilometerVelocity;
    }

    public double getKilometerVelocity() {
        return kilometerVelocity;
    }
}
