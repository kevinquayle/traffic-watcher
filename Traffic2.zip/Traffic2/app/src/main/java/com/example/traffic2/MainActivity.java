package com.example.traffic2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showSpeed();
    }

    public void showSpeed() {
        Intent intent = getIntent();
        TextView textView = findViewById(R.id.speed_number);
        TextView title = findViewById(R.id.camera_id);
        title.setText("Camera: " + MapsActivity.cameraList.get(intent.getIntExtra("CAMERA_ID", 0)).getName());
        double doub = (MapsActivity.cameraList.get(intent.getIntExtra("CAMERA_ID", 0)).getKilometerVelocity());
        textView.setText(String.format("%.2f\nkm/h", doub));
    }
}
