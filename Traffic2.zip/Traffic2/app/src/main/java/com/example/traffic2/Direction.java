package com.example.traffic2;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
