package com.example.traffic2;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    public static ArrayList<Camera> cameraList;
    private int numCircles = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }



    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        cameraList = new ArrayList<>();

        instantiateCameras();

        for (Camera camera : cameraList) {
            makeCircle(camera);
        }

        LatLng position = new LatLng(33.774100, -84.391136);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(position));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));

        // LocationManager mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(mLocationManager.getLastKnownLocation()));

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("cameras");



        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                for(DataSnapshot camera : dataSnapshot.getChildren()) {
                    String cameraID = camera.getKey();
                    Log.d("Firebase", "Key is: " + cameraID);
                    Double speed = camera.getValue(Double.class);
                    Log.d("Firebase", "Value is: " + speed);
                    cameraList.get(Integer.parseInt(cameraID)).setKilometerVelocity(speed);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Firebase", "Failed to read value.", error.toException());
            }
        });

        mMap.setOnCircleClickListener(new GoogleMap.OnCircleClickListener() {
            @Override
            public void onCircleClick(Circle circle) {
                Intent intent = new Intent(MapsActivity.this, MainActivity.class);
                intent.putExtra("CAMERA_ID", (int) circle.getZIndex());
                startActivity(intent);
            }
        });

    }

    private void makeCircle(Camera location) {
        CircleOptions circle = new CircleOptions().center(location.getLocation()).clickable(true).strokeWidth(10.0f).fillColor(Color.GREEN).radius(15).zIndex(numCircles);
        mMap.addCircle(circle);
        numCircles++;
    }

    private void instantiateCameras() {
        cameraList.add(new Camera("150", new LatLng(33.790993, -84.392750), "http://vss2live.dot.ga.gov:80/lo/gdot-cam-150.stream/playlist.m3u8", Direction.SOUTH));
        cameraList.add(new Camera("20", new LatLng(33.786790, -84.391585), "http://vss2live.dot.ga.gov:80/lo/gdot-cam-020.stream/playlist.m3u8", Direction.SOUTH));
        cameraList.add(new Camera("19", new LatLng(33.783338, -84.391184), "http://vss2live.dot.ga.gov:80/lo/gdot-cam-019.stream/playlist.m3u8", Direction.SOUTH));
        cameraList.add(new Camera("18", new LatLng(33.780502, -84.391238), "http://vss2live.dot.ga.gov:80/lo/gdot-cam-018.stream/playlist.m3u8", Direction.SOUTH));
        cameraList.add(new Camera("17", new LatLng(33.774429, -84.390508), "http://vss2live.dot.ga.gov:80/lo/gdot-cam-017.stream/playlist.m3u8", Direction.SOUTH));
    }
}
 //